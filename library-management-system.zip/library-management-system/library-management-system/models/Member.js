import { Schema, model } from 'mongoose';
import { hash, compare } from 'bcryptjs';

const MemberSchema = new Schema({
    name: { type: String,reuired:true },
    email:{ type: String, required: true, unquired: true},
    password:{type: String, require: true},
    role: { types: String, enum: ['user', 'admin'], default: 'user'}
     });

MemberSchema.pre('save', async.function(next)){
    if(this.isModified('password')){
        this.password = await hash(this.password, 10);
    }
    next();
};
MemberSchema.methods.comparePassword = function(password){
    return compare(password, this.password);
}     
export default model('Member', MemberSchema);