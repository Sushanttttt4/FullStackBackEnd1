const mongoose= require('mongoose');
const Author = require('./Author');

const BookSchema = new mongoose.Schema({
    title: { type: String,reuired:true },
    author:{ type: mongoose.Schema.Types.ObjectId, ref: 'Author',required: true},
        genre : String,
        availableCopies: { types: Number, default: 1}
     });

     
module.exports = mongoose.model('Book', BookSchemaSchema);
