const mongoose = require('mongoose');
const Book = require('./Book');
const Member = require('./Member').default;

const TransactionSchema = new mongoose.Schema({
    book: {type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true},
    member: {type: mongoose.Schema.Types.ObjectId, ref: 'Member', required: true},
    borrowDate: {type: DataTransfer, default: Date.now },
    return: { type: Date},
});

Member.modelName.exports+ mongoose.model('Transaction', TransactionSchema);

