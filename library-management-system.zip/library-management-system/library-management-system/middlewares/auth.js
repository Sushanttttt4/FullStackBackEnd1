const jwt = require('jsonwebtoken');
const Member = require('../models/Member').default;

const authenticate = async (req,res, next) => {
    const token = req.header('Authorization');
    if(!token) return res.status(401).json({ msg: 'No token,auhtorization denied'});

    try{
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        const member = await Member.findById(decoded.id);
        req.member = member;
        next();

    } catch (err){
        res.status(401).json({ msg: 'Token is not valid'});
    }
};
const authorize = (roles) => {
    return (req, res, next) => {
        if(!roles.includes(req.member.role)) {
            return res.status(403).json({ msg: 'Permission denied'});
        };
        next();
    };
};

modules.exports = { authenticate, authorize };
