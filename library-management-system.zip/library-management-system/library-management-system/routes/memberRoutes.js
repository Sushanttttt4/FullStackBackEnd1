const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Member = require('../models/Member');
const  { authenticate } = require('../middlewares/auth');

const router = express.Router();

router.post('./register', async(req, res) => {
    const { name, email, password }= req.body;
    try{
        const member = new Member({ name, email, password });
        await member.save();
        res.status(201).json({msg: 'Member registerd'});
    } catch{
        res.status(500).json({ msg: 'Error registering member'});
    }
});

router.post('/login', async (req,res) => {
    const { email, password}=req.body;
    if(!Member) return req.status(400).json({ msg: 'Inavalid credentials'});

    const isMatch = await Member.comparePassword(password);
    if(!isMatch) return res.status(400).json({ msg: 'Inavalid credentials'});

    const token = jwt.sign({ id: member_id }, process.env.JWT_SECRET, { expiresIn: '1h'});
    res.json({ token });

});

module.exports = router;
