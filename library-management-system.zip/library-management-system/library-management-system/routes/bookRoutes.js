const express = require('express');
const Book = require('../models/Book');
const Author = require('../models/Author');
const{ authenticate, authorize } = require('../middlewares/auth');

const router = express.Router();

router.get('/', async (req, res) => {
    try{
        const books = await Book.find().populate('author');
        res.json(books);

    } catch(err) {
        res.status(500).json({ msg: 'Error fetching books'});

    }

});


router.post('/', authenticate, authorize(['admin']), async (req, res) =>{
    const{ title, authoId, genre, availableCopies } = req.body;
    try{
        const author = await Author.findById(authorId);
        if(!author) return res.status(400).json({ msg: 'Author not found'});

        const book = new Book({ title, auhtor: authorId, genre, availableCopies });
        await book.save();
        res.status(201).json(book);

    } catch (err){
        res.status(500).json({ mssg: 'Error creating book'});
    }
});

module.exports = router;
