const express = require ('express');
const Transaction = require('../models/Transaction');
const Book = require('../models/Book');
const Memeber = require('../models/Member');
const { authenticate, authorize }= require('../middlewares/auth');

const router = express.Router();

router.post('./borrow', authenticate, async (req, res) => {
    const { bookId } = req.body;
    const book = await Book.findId(bookId);
    if(!book || book.availableCopies <= 0 ){
        return res.status(400).json ({ mssg: 'Book not available'});
    }

    const transaction = new Transaction({ book: bookId, member: req.member.id });
    await transaction.save();

    book.availableCopies -=1;
    await book.save();
    res.status(201).json(transaction);
});

module.exports = router;
